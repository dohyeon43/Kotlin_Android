# Room과 Shared Preferences

(SQLite, Saved Instance State)

## 1. SharedPreferences

---

**SharedPrefrences**는 소량의 데이터를 키/값의 형식으로 저장하고, **SharedPreferences API** 를 통해 값을 읽고 쓰고 관리할 수 있다.

**SharedPreferences**는 앱 내부에 xml의 형태로 데이터를 저장한다.

액티비티에서 자주 사용되는 **Saved Instance State**와 비교한 표이다.

![Untitled](Room%E1%84%80%E1%85%AA%20Shared%20Preferences%20db43dfc3884b457dace27ec240b8e772/Untitled.png)